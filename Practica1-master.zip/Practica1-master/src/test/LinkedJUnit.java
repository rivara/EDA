package test;
import static org.junit.Assert.*;

import org.junit.Test;

import Queue.LinkedQueue;


public class LinkedJUnit {

	@Test
	public void testsize() {
		LinkedQueue<Integer> queue = new LinkedQueue<Integer> ();
		assertTrue (queue.size()==0);
		queue.enqueue(new Integer (5));
		queue.enqueue(new Integer (6));
		queue.enqueue(new Integer (7));
		assertTrue (queue.size()==3);
		queue.dequeue();
		assertTrue(queue.size()==2);
		
	}

}
