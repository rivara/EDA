package Queue;


public class ArrayQueue<E> implements Queue<E> {
	private E[] elementos;
	private int principio,fin;
	private int tam;
	
	public ArrayQueue (int tam) {
		this.tam= 0;
		this.principio = 0;
		this.fin = 0;
		this.elementos = (E[]) new Object [tam];
	}
	/**
	* Returns the number of elements in the queue. * @return number of elements in the queue.
	*/
	public int size() {
		return tam;
	}
	/**
	* Returns whether the queue is empty.
	* @return true if the queue is empty, false otherwise. */
	public boolean isEmpty() {
		return (tam==0);
	}
	/**
	* Inspects the element at the front of the queue. * @return element at the front of the queue.
	*/
	public E front() {
		if (this.tam==0) {
			throw new RuntimeException ("Es Vacia");
		}
		return this.elementos[this.principio];
	}
	/**
	* Inserts an element at the rear of the queue. * @param element new element to be inserted. */
	public void enqueue (E element){
		if (this.tam==this.elementos.length) {
			throw new RuntimeException ("Es llena");
		}
		
		if (this.tam==0) {
			this.elementos[this.fin] = element;
		}else {
			this.fin = (this.fin + 1) % this.elementos.length;
		}
		this.tam++;
	}
	/**
	* Removes the element at the front of the queue. * @return element removed.
	*/
	public E dequeue() {
		if (this.tam==0) {
			throw new RuntimeException ("Es Vacia");
		}
		E aux = this.elementos[this.principio];
		this.principio=(this.principio+1) % this.elementos.length;
		this.tam--;
		return aux;
	}

}
