package Queue;


public class LinkedQueue<E> implements Queue<E> {
	
	class Nodo<T> {
        T info;
        Nodo<T> sig;
    }
    
    private Nodo<E> principio,fin;
    private int tam;
    
    public LinkedQueue () {
    	tam =0;
    	principio = null;
    	fin = null;
    }
    
    
    
	/**
	* Returns the number of elements in the queue. * @return number of elements in the queue.
	*/
	public int size() {
		return tam;
	}
	/**
	* Returns whether the queue is empty.
	* @return true if the queue is empty, false otherwise. */
	public boolean isEmpty() {
		return (tam==0);
	}
	/**
	* Inspects the element at the front of the queue. * @return element at the front of the queue.
	*/
	public E front() {
		if (isEmpty ()) {
			throw new RuntimeException ("Es Vacia");
		}
		return this.principio.info;
	}
	/**
	* Inserts an element at the rear of the queue. * @param element new element to be inserted. */
	public void enqueue (E element) {
		Nodo<E> nuevo;
        nuevo = new Nodo<E> ();
        nuevo.info = element;
        nuevo.sig = null;
        if (isEmpty ()) {
            principio = nuevo;
            fin = nuevo;
        } else {
            fin.sig = nuevo;
            fin = nuevo;
        }
        this.tam++;
	}
	/**
	* Removes the element at the front of the queue. * @return element removed.
	*/
	public E dequeue() {
		if (isEmpty ()) {
			throw new RuntimeException ("Es Vacia");
		}
		E informacion = principio.info;
        if (this.principio == this.fin){
        	principio = null;
        	fin = null;
        } else {
        	principio = principio.sig;
        }
        this.tam--;
        
        return informacion;
        
	}
}
