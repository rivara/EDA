package Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;

import material.tree.binarysearchtree.LinkedBinarySearchTree;
import material.tree.binarysearchtree.Position;
import material.tree.binarysearchtree.RBTree;

import org.junit.Test;

public class findRangeTest {

	@Test
	public void testABB() {
		// nos creamos un �rbol binario de b�squeda
		LinkedBinarySearchTree<Integer> arbol = new LinkedBinarySearchTree<>();
		arbol.insert(10);
		arbol.insert(5);
		arbol.insert(10);
		arbol.insert(4);
		arbol.insert(18);
		arbol.insert(3);
		arbol.insert(12);
		arbol.insert(20);
		arbol.insert(2);
		arbol.insert(14);
		arbol.insert(19);
		arbol.insert(23);

		Iterable<Position<Integer>> itera = arbol.findRange(5, 20);
		ArrayList<Position<Integer>> lista = new ArrayList<>();
		Iterator<Position<Integer>> it = itera.iterator();
		String salida = "";
		while (it.hasNext()) {
			Position<Integer> pos = it.next();
			salida += pos.getElement() + " ";
			lista.add(pos);
		}
		System.out.println(salida);
		assertTrue(salida.equals("10 5 10 18 12 14 20 19 "));
		assertTrue(lista.size() == 8);

		arbol.insert(6);
		arbol.insert(5);
		itera = arbol.findRange(5, 12);
		lista = new ArrayList<>();
		it = itera.iterator();
		salida = "";
		while (it.hasNext()) {
			Position<Integer> pos = it.next();
			salida += pos.getElement() + " ";
			lista.add(pos);
		}

		assertTrue(salida.equals("10 5 6 5 10 12 "));
		assertTrue(lista.size() == 6);
	}

	@Test
	public void testAVL() {
		RBTree<Integer> arbol = new RBTree<>();
		arbol.insert(10);
		arbol.insert(5);
		arbol.insert(10);
		arbol.insert(4);
		arbol.insert(18);
		arbol.insert(3);
		arbol.insert(12);
		arbol.insert(50);
		arbol.insert(2);
		arbol.insert(14);
		arbol.insert(19);
		arbol.insert(23);
		Iterable<Position<Integer>> itera = arbol.findRange(10, 20);
		ArrayList<Position<Integer>> lista = new ArrayList<>();
		Iterator<Position<Integer>> it = itera.iterator();
		String salida = "";
		while (it.hasNext()) {
			Position<Integer> pos = it.next();
			salida += pos.getElement() + " ";
			System.out.println(pos.getElement());
			lista.add(pos);
		}
	}

	@Test
	public void testARN() {
		RBTree<Integer> arbol = new RBTree<>();

		arbol.insert(10);
		arbol.insert(5);
		arbol.insert(10);
		arbol.insert(4);
		arbol.insert(18);
		arbol.insert(3);
		arbol.insert(12);
		arbol.insert(50);
		arbol.insert(2);
		arbol.insert(14);
		arbol.insert(19);
		arbol.insert(23);
		Iterable<Position<Integer>> itera = arbol.findRange(10, 20);
		ArrayList<Position<Integer>> lista = new ArrayList<>();
		Iterator<Position<Integer>> it = itera.iterator();
		String salida = "";
		while (it.hasNext()) {
			Position<Integer> pos = it.next();
			salida += pos.getElement() + " ";
			System.out.println(pos.getElement());
			lista.add(pos);
		}

	}
}
