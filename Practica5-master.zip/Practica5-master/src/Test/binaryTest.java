package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import material.tree.binarysearchtree.AVLTree;
import material.tree.binarysearchtree.LinkedBinarySearchTree;
import material.tree.binarysearchtree.Position;
import material.tree.binarysearchtree.RBTree;

public class binaryTest {

	@Test
	public void test() {
		// nos creamos un �rbol binario de b�squeda
		LinkedBinarySearchTree<Integer> arbol = new LinkedBinarySearchTree<>();
		arbol.insert(5);
		arbol.insert(9);
		Position<Integer> pos1 = arbol.insert(4);
		arbol.insert(2);
		arbol.insert(18);
		arbol.insert(7);
		arbol.insert(19);
		arbol.insert(11);

		Integer last = arbol.last().getElement();
		Integer first = arbol.first().getElement();
		assertTrue(last == 19);
		assertTrue(first == 2);

		Iterable<Position<Integer>> suc = arbol.successors(pos1);
		String cadena = "";
		for (Position<Integer> p : suc) {
			cadena += p.getElement() + " ";
		}
		// comprobacion
		cadena.equals("5 9 7 18 11 19 ");

		cadena = "";
		Iterable<Position<Integer>> pred = arbol.predecessors(pos1);
		for (Position<Integer> p : pred) {
			cadena += p.getElement() + " ";
		}

		cadena.equals("2 ");

	}

	@Test
	public void testAVL() {
		// nos creamos un �rbol binario de b�squeda
		AVLTree<Integer> arbol = new AVLTree<>();
		arbol.insert(5);
		arbol.insert(9);
		Position<Integer> pos1 = arbol.insert(4);
		arbol.insert(2);
		arbol.insert(18);
		arbol.insert(7);
		arbol.insert(19);
		arbol.insert(11);

		Integer last = arbol.last().getElement();
		Integer first = arbol.first().getElement();
		assertTrue(last == 19);
		assertTrue(first == 2);

		Iterable<Position<Integer>> suc = arbol.successors(pos1);
		String cadena = "";
		for (Position<Integer> p : suc) {
			cadena += p.getElement() + " ";
		}
		cadena.equals("5 9 7 18 11 19 ");
		cadena = "";
		Iterable<Position<Integer>> pred = arbol.predecessors(pos1);
		for (Position<Integer> p : pred)
			cadena += p.getElement() + " ";

		cadena.equals("2 ");
	}

	@Test
	public void testARN() {
		// nos creamos un �rbol binario de b�squeda
		RBTree<Integer> arbol = new RBTree<>();
		arbol.insert(5);
		arbol.insert(9);
		Position<Integer> pos1 = arbol.insert(4);
		arbol.insert(2);
		arbol.insert(18);
		arbol.insert(7);
		arbol.insert(19);
		arbol.insert(11);
		Integer last = arbol.last().getElement();
		Integer first = arbol.first().getElement();
		assertTrue(last == 19);
		assertTrue(first == 2);

		Iterable<Position<Integer>> suc = arbol.successors(pos1);
		String cadena = "";
		for (Position<Integer> p : suc) {
			cadena += p.getElement() + " ";
		}
		cadena.equals("5 9 7 18 11 19 ");

		cadena = "";
		Iterable<Position<Integer>> pred = arbol.predecessors(pos1);
		for (Position<Integer> p : pred) {
			cadena += p.getElement() + " ";
		}
		assertTrue(cadena.equals("2 "));

	}

}
