package CasoDeUso;
/*
� String name // name and surname
� int age // age of the student
� int record // record number in the university
� double mark // average qualification in the university
Para cada �rbol (BST, AVL y RB), se pide la implementaci�n de tres criterios distintos de
comparaci�n: por nombre (alfab�tico), por edad (de menor a mayor) y por nota (de
menor a mayor).*/

public class Students {
    //Atributos
	private String name;
	private int age;
	private int record;
	private Double mark;
	
	//constructor
	public Students(String n,int a,int r,Double m){
		this.name=n;
		this.age=a;
		this.record=r;
		this.mark=m;
	}
	//geter seters

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getRecord() {
		return record;
	}

	public void setRecord(int record) {
		this.record = record;
	}

	public Double getMark() {
		return mark;
	}

	public void setMark(Double mark) {
		this.mark = mark;
	}
	
	
}
