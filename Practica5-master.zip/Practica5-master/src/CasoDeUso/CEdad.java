package CasoDeUso;

import java.util.Comparator;

public class CEdad implements Comparator<Students>{

	@Override
	public int compare(Students o1, Students o2) {
		Integer age1=o1.getAge();
		Integer age2= o2.getAge();
		return age1.compareTo(age2);
	}

}
