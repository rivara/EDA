package CasoDeUso;

import java.util.Comparator;

public class CNota implements Comparator<Students>{

	@Override
	public int compare(Students o1, Students o2) {
	Double nota1= o1.getMark();
	Double nota2= o2.getMark();
	return nota1.compareTo(nota2);
	
	}

}
