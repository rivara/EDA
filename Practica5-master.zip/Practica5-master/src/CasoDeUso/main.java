package CasoDeUso;

import material.tree.binarysearchtree.LinkedBinarySearchTree;
import material.tree.binarysearchtree.AVLTree;
import material.tree.binarysearchtree.RBTree;

public class main {
	public static void main(String args[]) {
		// instanciacion
		CNota cn = new CNota();
		CEdad ce = new CEdad();
		CName cna = new CName();

		// LinkedBinarySearchTree
		System.out.println();
		System.out.println("LinkedBinarySearchTree");
		LinkedBinarySearchTree<Students> arbol1 = new LinkedBinarySearchTree<Students>(
				cn);
		arbol1.insert(new Students("Pepe", 22, 8, 8.5));
		arbol1.insert(new Students("Carlos", 24, 8, 6.5));
		arbol1.insert(new Students("Ana", 28, 8, 9.5));
		arbol1.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbol1.first().getElement().getMark());


		LinkedBinarySearchTree<Students> arbol2 = new LinkedBinarySearchTree<Students>(
				ce);
		arbol2.insert(new Students("Pepe", 22, 8, 8.5));
		arbol2.insert(new Students("Carlos", 24, 8, 6.5));
		arbol2.insert(new Students("Ana", 28, 8, 9.5));
		arbol2.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbol2.first().getElement().getAge());

		LinkedBinarySearchTree<Students> arbol3 = new LinkedBinarySearchTree<Students>(
				cna);
		arbol3.insert(new Students("Pepe", 22, 8, 8.5));
		arbol3.insert(new Students("Carlos", 24, 8, 6.5));
		arbol3.insert(new Students("Ana", 28, 8, 9.5));
		arbol3.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbol3.first().getElement().getName());

		// AVLTree
		System.out.println();
		System.out.println("AVLTree");
		//AVLTree<StudentsRB_AVL_Nota> arbolAVL1 = new AVLTree<StudentsRB_AVL_Nota>();
		AVLTree<Students> arbolAVL1 = new AVLTree<Students>(cn);
		arbolAVL1.insert(new Students("Pepe", 22, 8, 8.5));
		arbolAVL1.insert(new Students("Carlos", 24, 8, 6.5));
		arbolAVL1.insert(new Students("Ana", 28, 8, 9.5));
		arbolAVL1.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbolAVL1.first().getElement().getMark());

		AVLTree<Students> arbolAVL2 = new AVLTree<Students>(ce);
		arbolAVL2.insert(new Students("Pepe", 22, 8, 8.5));
		arbolAVL2.insert(new Students("Carlos", 24, 8, 6.5));
		arbolAVL2.insert(new Students("Ana", 28, 8, 9.5));
		arbolAVL2.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbolAVL2.first().getElement().getAge());

		AVLTree<Students> arbolAVL3 = new AVLTree<Students>(cna);
		arbolAVL3.insert(new Students("Pepe", 22, 8, 8.5));
		arbolAVL3.insert(new Students("Carlos", 24, 8, 6.5));
		arbolAVL3.insert(new Students("Ana", 28, 8, 9.5));
		arbolAVL3.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbolAVL3.first().getElement().getName());

		// RBTree
		System.out.println();
		System.out.println("RBTree");
		RBTree<Students> arbolRB1 = new RBTree<Students>(cn);
		arbolRB1.insert(new Students("Pepe", 22, 8, 8.5));
		arbolRB1.insert(new Students("Carlos", 24, 8, 6.5));
		arbolRB1.insert(new Students("Ana", 28, 8, 9.5));
		arbolRB1.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbolRB1.first().getElement().getAge());

		RBTree<Students> arbolRB2 = new RBTree<Students>(ce);
		arbolRB2.insert(new Students("Pepe", 22, 8, 8.5));
		arbolRB2.insert(new Students("Carlos", 24, 8, 6.5));
		arbolRB2.insert(new Students("Ana", 28, 8, 9.5));
		arbolRB2.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbolRB2.first().getElement().getAge());

		RBTree<Students> arbolRB3 = new RBTree<Students>(cna);
		arbolRB3.insert(new Students("Pepe", 22, 8, 8.5));
		arbolRB3.insert(new Students("Carlos", 24, 8, 6.5));
		arbolRB3.insert(new Students("Ana", 28, 8, 9.5));
		arbolRB3.insert(new Students("Luis", 19, 8, 5.5));
		System.out.println(arbolRB3.first().getElement().getName());

	}

}