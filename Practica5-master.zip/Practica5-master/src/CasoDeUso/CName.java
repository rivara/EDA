package CasoDeUso;

import java.util.Comparator;

public class CName implements Comparator<Students>{

	@Override
	public int compare(Students arg0, Students arg1) {
		String name1=arg0.getName();
		String name2=arg1.getName();
		return name1.compareTo(name2);
	}

}
