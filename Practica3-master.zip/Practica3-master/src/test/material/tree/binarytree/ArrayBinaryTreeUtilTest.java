/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.material.tree.binarytree;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import material.tree.Position;
import material.tree.binarytree.ArrayBinaryTree;
import material.tree.binarytree.BinaryTreeUtils;
import material.tree.binarytree.LinkedBinaryTree;
import material.tree.iterator.BFSIteratorFactory;

import org.junit.Test;
/**
 *
 * @author J. Vélez, A. Duarte, J. Sánchez-Oro
 */
public class ArrayBinaryTreeUtilTest {
    
    /**
     * T * Test of mirror contains  method, of class ArrayBinarytreeUtils
     */
   @Test
    public void testMirror() {
    	ArrayBinaryTree<String> t = new ArrayBinaryTree<String>(10);
    	BinaryTreeUtils<String> bt= new BinaryTreeUtils<String>(t);
        boolean esta=true;
    	Position<String> root=t.addRoot("0");
		Position<String> der1 = t.insertRight(root, "+");
		Position<String> izq1 = t.insertLeft(root, "-");
		Position<String> der11 = t.insertRight(izq1, "/");
		Position<String> izq11 = t.insertLeft(izq1, "*");
		ArrayList<String> lista = new ArrayList<String>();
		lista.add("0");
		lista.add("-");
		lista.add("+");
		lista.add("*");
		lista.add("/");
		
		BFSIteratorFactory preordeniteratorfactory = new BFSIteratorFactory();
		t.setIterator(preordeniteratorfactory);

		Iterator<String> it = lista.iterator();
		bt.mirror();
		Iterator<Position<String>> it2 = t.iterator();
		while (it.hasNext()) {
			if (!it.next().equals(it2.next().getElement()))
				esta = false;

		}
		assertTrue(esta);
	}
    	
    	


    /**
     * Test of contains  method, of class ArrayBinarytreeUtils.
     */
    @Test
    public void testContains() {
    	ArrayBinaryTree<String> t = new ArrayBinaryTree<String>(10);
    	BinaryTreeUtils<String> bt= new BinaryTreeUtils<String>(t);
    	Position<String> root=t.addRoot("w");
		Position<String> der1 = t.insertRight(root, "2");
		Position<String> izq1 = t.insertLeft(root, "3");
		Position<String> izq11 = t.insertLeft(izq1, "33");
		System.out.println(bt.contains("3"));
		assertEquals(bt.contains("3"),true);
    }

    /**
     * Test of level  method, of class ArrayBinarytreeUtils.
     */
    @Test
    public void testLevel() {
    	ArrayBinaryTree<String> t = new ArrayBinaryTree<String>(10);
    	BinaryTreeUtils<String> bt= new BinaryTreeUtils<String>(t);
    	Position<String> root=t.addRoot("w");
		Position<String> der1 = t.insertRight(root, "2");
		Position<String> izq1 = t.insertLeft(root, "3");
		Position<String> izq11 = t.insertLeft(izq1, "33");
		assertEquals(bt.level(izq1), 1);
    }

    
    
   
    
}
