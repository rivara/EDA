package material.tree.binarytree;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import material.tree.*;
import material.tree.binarytree.LinkedBinaryTree.BTNode;
import material.tree.iterator.BFSIteratorFactory;
import material.tree.iterator.TreeIteratorFactory;

/**
 * *
 * 
 * @author A. Duarte, J. V�lez, J. S�nchez-Oro
 * @param <E>
 *            The type of the elements in the tree
 * @see BinaryTree
 */
public class ArrayBinaryTree<E> implements BinaryTree<E> {

	private class BTPos<T> implements Position<T> {

		private T element;
		private int index;
		private ArrayBinaryTree<BTPos<T>> myTree;

		public BTPos(ArrayBinaryTree<BTPos<T>> myTree, T element, int index) {

			this.myTree = myTree;
			this.element = element;
			this.index = index;
		}

		@Override
		public T getElement() {
			return element;
		}

		public void setElement(T o) {
			element = o;
		}

		public void setTree(ArrayBinaryTree<BTPos<T>> myTree) {
			this.myTree = myTree;
		}

		public ArrayBinaryTree<BTPos<T>> getTree() {
			return myTree;
		}

		public int getIndex() {
			return index;
		}

		public void setIndex(int index) {
			this.index = index;
		}
	}

	private BTPos<E>[] tree;
	private int size;
	private TreeIteratorFactory<E> iteratorFactory; // The factory of iterators

	/**
	 * Constructor of the class.
	 */

	public ArrayBinaryTree(int capacity) {
		tree = new BTPos[capacity];
		size = 0;
		this.iteratorFactory = new BFSIteratorFactory<>();
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return (size == 0);
	}

	@Override
	public boolean isInternal(Position<E> p) throws IllegalStateException {
		checkPosition(p);
		return (hasLeft(p) || hasRight(p));
	}

	@Override
	public boolean isLeaf(Position<E> p) throws IllegalStateException {
		return !isInternal(p);
	}

	@Override
	public boolean isRoot(Position<E> p) throws IllegalStateException {

		BTPos<E> node = checkPosition(p);
		return (node == tree[1]);

	}

	@Override
	public boolean hasLeft(Position<E> p) throws IllegalStateException {
		BTPos<E> node = checkPosition(p);
		int indice = node.index;

		if (((indice * 2) < this.tree.length)
				&& (this.tree[indice * 2] != null))
			return true;

		return false;
	}

	@Override
	public boolean hasRight(Position<E> p) throws IllegalStateException {
		BTPos<E> node = checkPosition(p);
		int indice = node.index;

		if ((((indice * 2) + 1) < this.tree.length)
				&& (this.tree[(indice * 2) + 1] != null))
			return true;

		return false;
	}

	@Override
	public Position<E> root() throws IllegalStateException {
		if (tree[1] == null) {
			throw new IllegalStateException("The tree is empty");
		}
		return tree[1];
	}

	@Override
	public Position<E> left(Position<E> p) throws IllegalStateException {
		BTPos<E> node = this.checkPosition(p);
		Integer leftPos = node.index * 2;// obtenemos la posicion del izquierdo
		if (tree[leftPos] == null) {
			throw new IllegalStateException("No left child");
		}
		return tree[leftPos]; // accedemos a la posicion del array
	}

	@Override
	public Position<E> right(Position<E> p) throws IllegalStateException,
			IndexOutOfBoundsException {
		BTPos<E> node = this.checkPosition(p);
		Integer rightPos = node.index * 2 + 1;// obtenemos la posicion del
												// izquierdo
		if (tree[rightPos] == null) {
			throw new IllegalStateException("No right child");
		}
		return tree[rightPos]; // accedemos a la posicion del array
	}

	@Override
	public Position<E> parent(Position<E> p) throws IllegalStateException,
			IndexOutOfBoundsException {
		BTPos<E> node = this.checkPosition(p);
		if (node.index % 2 == 0)
			return tree[node.index / 2];
		else
			return tree[(node.index - 1) / 2];
	}

	@Override
	public Iterable<Position<E>> children(Position<E> p)
			throws IllegalStateException {
		List<Position<E>> children = new ArrayList<Position<E>>();
		if (hasLeft(p)) {
			children.add(left(p));
		}
		if (hasRight(p)) {
			children.add(right(p));
		}
		return children;
	}

	@Override
	public E replace(Position<E> p, E e) throws IllegalStateException {
		BTPos<E> node = checkPosition(p);
		node.setElement(e);
		return e;
	}

	// Additional Methods
	@Override
	public Position<E> sibling(Position<E> p) throws IllegalStateException,
			IndexOutOfBoundsException {
		BTPos<E> node = checkPosition(p);
		if (node.index % 2 == 0)
			return tree[node.index + 1];
		else
			return tree[node.index - 1];

	}

	@Override
	public Position<E> addRoot(E e) throws IllegalStateException {
		if (!this.isEmpty()) {
			throw new IllegalStateException("Tree already has a root");
		}
		// //////////////////// si la longitud es menor o igual a 1
		if (tree.length <= 1) {
			tree = new BTPos[2];
		}
		// ////////////////////
		BTPos<E> node = new BTPos<E>(
				(ArrayBinaryTree<ArrayBinaryTree<E>.BTPos<E>>) this, e, 1);
		tree[1] = node;
		size = 1;
		// RVR Comprobaciones izquierda derecha
		// ////////////////////////////////
		/*
		 * if( node.index *2+1 >=tree.length){ //ampliamos a la maxima posicion
		 * izquierda + //lado impar +1 ya que java empieza en 0 BTPos<E>[]
		 * newtree = new BTPos[ node.index *2+2];//[ node.index *2+1];
		 * tree=newtree; tree[1] = node; size = 1; }
		 */
		// ////////////////////////////////////
		return node;
	}

	@Override
	public Position<E> insertLeft(Position<E> p, E e)
			throws IllegalStateException {
		BTPos<E> node = checkPosition(p);
		int leftPos = node.index * 2;

		// si se desborda la tabla ampliamos
		if (tree.length <= leftPos) {
			// hay que a�adir nuevas posiciones al arrayList
			// BTPos<E>[] new_tree = new BTPos[leftPos+1];
			// OJO
			BTPos<E>[] new_tree = new BTPos[tree.length * 2];
			for (int i = 0; i < tree.length; i++) {
				new_tree[i] = tree[i];
			}
			tree = new_tree;
		}

		if (tree[leftPos] != null) { // Ya tiene un hijo a la izquierda
			throw new IllegalStateException("Node already has a left child");
		}
		BTPos<E> nuevo = new BTPos(
				(ArrayBinaryTree<ArrayBinaryTree<E>.BTPos<E>>) this, e, leftPos);
		tree[leftPos] = nuevo;
		size++;
		return nuevo;
	}

	public Position<E> insertRight(Position<E> p, E e)
			throws IllegalStateException {
		BTPos<E> node = checkPosition(p);

		int rightPos = (node.index * 2) + 1;

		// si se desborda la tabla ampliamos
		if (tree.length <= rightPos) {
			// hay que a�adir nuevas posiciones al arrayList
			// BTPos<E>[] new_tree = new BTPos[rightPos+1];
			// BTPos<E>[] new_tree = new BTPos[leftPos+1];
			// OJO
			BTPos<E>[] new_tree = new BTPos[tree.length * 2 + 1];

			for (int i = 0; i < tree.length; i++) {
				new_tree[i] = tree[i];
			}
			tree = new_tree;
		}
		if (tree[rightPos] != null) {
			throw new IllegalStateException("Node already has a right child");
		}

		BTPos<E> nuevo = new BTPos<E>(
				(ArrayBinaryTree<ArrayBinaryTree<E>.BTPos<E>>) this, e,
				rightPos);
		tree[rightPos] = nuevo;
		size++;
		return nuevo;
	}

	@Override
	public void swapElements(Position<E> p1, Position<E> p2)
			throws IllegalStateException {
		BTPos<E> node1 = checkPosition(p1);
		BTPos<E> node2 = checkPosition(p2);
		E temp = p2.getElement();
		tree[node2.index].setElement(p1.getElement());
		tree[node1.index].setElement(temp);
	}

	/**
	 * Determines whether the given position is a valid node.
	 *
	 * @param v
	 *            the position to be checked
	 * @return the position casted to BTPos
	 */
	private BTPos<E> checkPosition(Position<E> v) throws IllegalStateException {
		if (v == null || !(v instanceof BTPos)) {
			throw new IllegalStateException("The position is invalid");
		}
		BTPos<E> btpos = (BTPos<E>) v;
		if (btpos.myTree != this) {
			throw new IllegalStateException(
					"The position does not belong to this tree");
		}
		return (BTPos<E>) v;
	}

	/**
	 * Converts the node passed by parameter in the new root.
	 *
	 * @param v
	 *            new root node
	 */
	@Override
	public E remove(Position<E> p) throws IllegalStateException {
		BTPos<E> pos = this.checkPosition(p);

		if (hasLeft(p) && hasRight(p)) {
			throw new IllegalStateException(
					"Can not remove node with two children");
		}
		BTPos<E> childBtpos;
		if (hasLeft(p)) {
			childBtpos = (BTPos<E>) left(p);
		} else if (hasRight(p)) {
			childBtpos = (BTPos<E>) right(p);
		} else {
			childBtpos = null;
		}

		if (this.isLeaf(p)) {
			tree[pos.index] = null;
			size--;
		} else {
			// 1-Guardamos la posici�n donde antes estaba el hijo
			int posicion_antigua_del_hijo = childBtpos.index;
			// 2- Guardamos el hijo en su nueva posicion
			tree[pos.index] = childBtpos;
			tree[childBtpos.index] = null;
			// childBtpos.setIndex(pos.index);
			// 3- Ahora actualizamos los hijos del que se ha movido
			if (tree[posicion_antigua_del_hijo * 2] != null)
				ActualizarHi(posicion_antigua_del_hijo * 2, pos.index);
			if (tree[(posicion_antigua_del_hijo * 2) + 1] != null) {
				ActualizarHd((posicion_antigua_del_hijo * 2) + 1, pos.index);
			}

			size--;
		}
		return pos.getElement();

	}

	protected void ActualizarHi(int pos_hijo_que_debe_moverse,
			int pos_nueva_de_su_padre) {
		tree[pos_nueva_de_su_padre * 2] = tree[pos_hijo_que_debe_moverse];
		tree[pos_hijo_que_debe_moverse] = null;

		if (tree[pos_hijo_que_debe_moverse * 2] != null)
			ActualizarHi(pos_hijo_que_debe_moverse * 2,
					pos_nueva_de_su_padre * 2);
		if (tree[(pos_hijo_que_debe_moverse * 2) + 1] != null)
			ActualizarHd((pos_hijo_que_debe_moverse * 2) + 1,
					pos_nueva_de_su_padre * 2);
	}

	protected void ActualizarHd(int pos_hijo_que_debe_moverse,
			int pos_nueva_de_su_padre) {
		tree[(pos_nueva_de_su_padre * 2) + 1] = tree[pos_hijo_que_debe_moverse];
		tree[pos_hijo_que_debe_moverse] = null;
		if (tree[pos_hijo_que_debe_moverse * 2] != null)
			ActualizarHi(pos_hijo_que_debe_moverse * 2,
					(pos_nueva_de_su_padre * 2) + 1);
		if (tree[(pos_hijo_que_debe_moverse * 2) + 1] != null)
			ActualizarHd((pos_hijo_que_debe_moverse * 2) + 1,
					(pos_nueva_de_su_padre * 2) + 1);
	}

	public void setIterator(TreeIteratorFactory<E> iteratorFactory) {
		this.iteratorFactory = iteratorFactory;
	}

	@Override
	public Iterator<Position<E>> iterator() {
		return this.iteratorFactory.createIterator(this);
	}

	/**
	 * Converts the node passed by parameter in the new root.
	 *
	 * @param v
	 *            new root node
	 */

	public void subTree(Position<E> v) {
		BTPos<E> raiz = checkPosition(v);
		BTPos<E>[] nuevo = new BTPos[this.tree.length];
		nuevo[1] = this.tree[raiz.index];
		copiar_recursivo(this.tree, raiz, nuevo, nuevo[1]);
		this.tree = nuevo;

	}

	public void copiar_recursivo(BTPos<E>[] origen, BTPos<E> raiz,
			BTPos<E>[] destino, BTPos<E> raiz_destino) {
		if (this.hasLeft(raiz)) {
			BTPos<E> izq = (BTPos<E>) this.left(raiz);
			int posicion_izq = raiz_destino.getIndex() * 2;
			BTPos<E> nueva_izq = new BTPos(this, izq.getElement(), posicion_izq);
			destino[posicion_izq] = nueva_izq;
			copiar_recursivo(origen, izq, destino, nueva_izq);
		}

		if (this.hasRight(raiz)) {
			BTPos<E> der = (BTPos<E>) this.right(raiz);
			int posicion_der = (raiz_destino.getIndex() * 2 + 1);
			BTPos<E> nueva_der = new BTPos(this, der.getElement(), posicion_der);
			destino[posicion_der] = nueva_der;
			copiar_recursivo(origen, der, destino, nueva_der);
		}
	}

	public Position<E> removeSubtree(Position<E> p)
			throws IllegalStateException {
		// si el nodo tiene izquierdo y derecho no vale
		BTPos<E> node = checkPosition(p);
		if ((this.hasLeft(p)) && (this.hasRight(p))) {
			throw new IllegalStateException("It isn't posible");
		}

		// rehago el arbol
		BTPos<E> raiz = checkPosition(this.root());
		BTPos<E>[] nuevo = new BTPos[this.tree.length];
		nuevo[1] = this.tree[raiz.index];
		copiar_recursivo(this.tree, raiz, nuevo, nuevo[1], node);
		this.tree = nuevo;

		return null;

	}

	public void copiar_recursivo(BTPos<E>[] origen, BTPos<E> raiz,
			BTPos<E>[] destino, BTPos<E> raiz_destino, BTPos<E> borrado) {

		if (this.hasLeft(raiz)) {
			if (this.left(raiz) == borrado) {
				System.out.println("ok2a");
				BTPos<E> izq = null;
				if (this.hasLeft(this.left(raiz))) {
					izq = (BTPos<E>) this.left(this.left(raiz));
				} else {
					izq = (BTPos<E>) this.right(this.left(raiz));
				}
				int posicion_der = (raiz_destino.getIndex() * 2 + 1);
				BTPos<E> nueva_der = new BTPos(this, izq.getElement(),posicion_der);
				destino[posicion_der] = nueva_der;
				copiar_recursivo(origen, izq, destino, nueva_der, borrado);
			} else {
				BTPos<E> izq = (BTPos<E>) this.left(raiz);
				int posicion_izq = raiz_destino.getIndex() * 2;
				BTPos<E> nueva_izq = new BTPos(this, izq.getElement(),posicion_izq);
				destino[posicion_izq] = nueva_izq;
				copiar_recursivo(origen, izq, destino, nueva_izq, borrado);
			}
		}

		if (this.hasRight(raiz)) {
			//cuando sea el econtrado adelanto posicion
			if (this.right(raiz) == borrado) {
				BTPos<E> der = null;
				if (this.hasLeft(this.right(raiz))) {
					der = (BTPos<E>) this.left(this.right(raiz));
				} else {
					der = (BTPos<E>) this.right(this.right(raiz));
				}
				int posicion_der = (raiz_destino.getIndex() * 2 + 1);
				BTPos<E> nueva_der = new BTPos(this, der.getElement(),posicion_der);
				destino[posicion_der] = nueva_der;
				copiar_recursivo(origen, der, destino, nueva_der, borrado);
			} else {
				//cuando sea el econtrado adelanto posicion		
				BTPos<E> der = (BTPos<E>) this.right(raiz);
				int posicion_der = (raiz_destino.getIndex() * 2 + 1);
				BTPos<E> nueva_der = new BTPos(this, der.getElement(),posicion_der);
				destino[posicion_der] = nueva_der;
				copiar_recursivo(origen, der, destino, nueva_der, borrado);
			}
		}
	}
}
