package material.tree.binarytree;

import java.util.ArrayDeque;
import java.util.Queue;

import javax.swing.text.html.HTMLDocument.Iterator;

import material.tree.Position;
import material.tree.binarytree.LinkedBinaryTree.BTNode;

public class BinaryTreeUtils<E> {
	
	

  private BinaryTree<E> binTree;
    
    public BinaryTreeUtils(BinaryTree<E> binTree) {
        this.binTree = binTree;
    }

    /**
     * Given a tree the method returns a new tree where all left children become
     * right children and vice versa
     * @return the mirror of the tree
     */
    public BinaryTree<E> mirror() {
    	   //defino la nueva estructura arbol
    	ArrayBinaryTree<E> newTree = new ArrayBinaryTree<E>(10);
        //si el arbol es vacio devuelve null
        if (binTree.isEmpty()) {
            return null;
        }
        //si no lo restructuro
        //empiezo por la raiz
        //tomo la referencia del puntero del arbol base
        Position<E> pOriginalRaiz = (Position<E>) binTree.root();
        Position<E> pNuevoRaiz = newTree.addRoot(binTree.root().getElement());
        //creo rama izquierda con la info de la derecha del original
        // Position<E> aux1=newTree.insertLeft(pNuevoRaiz,tree.right(pOriginalRaiz).getElement());
        Position<E> pa1I = newTree.root();
        Position<E> pa1D = newTree.root();

        int d = 0;
        Position<E> pa2I = null;
        Position<E> pa2D = null;
        for (Position<E> p2 : binTree) {

            if (!binTree.isLeaf(p2)) {
            	if(binTree.hasRight(p2)){
                pa2D = newTree.insertLeft(pa1D, binTree.right(p2).getElement());
                pa1D = pa2D;
            	}
            	if(binTree.hasLeft(p2)){
                pa2I = newTree.insertRight(pa1I, binTree.left(p2).getElement());
                pa1I = pa2I;
            	}
            	
            }

        }
        //retorno el arbol creado
        return newTree;
    }
    



    /**
     * Determines whether the element e is the tree or not
     * @param e the element to check
     * @return TRUE if e is in the tree, FALSE otherwise
     */
    public boolean contains(E e) {
        if (binTree.root().getElement().equals(e)) {
            return true;
        }
 
        boolean verdad = false;
        return containsAux(binTree, binTree.root(),e,verdad);
    }
    
    public boolean  containsAux(BinaryTree<E> binTree, Position<E> p,E e,boolean verdad) {
        
    	 for (Position<E> p1 : binTree.children(p)) {
             if (p1.getElement().equals(e)) {
                 verdad = true;
                 break;
             }
             if (binTree.hasLeft(p1) && binTree.hasRight(p1)) {
                 containsAux(binTree, p1, e,verdad);
             }
             if (binTree.hasLeft(p1) && !binTree.hasRight(p1)) {
                 if (binTree.left(p1).getElement().equals(e)) {
                     verdad = true;
                     break;
                 }
             }
             if (binTree.hasRight(p1) && !binTree.hasLeft(p1)) {
                 if (binTree.right(p1).getElement().equals(e)) {
                     verdad = true;
                     break;
                 }
             }
         }
 		return verdad;
     }
     
     
    
    

    /**
     * Determines the level of a node in the tree
     * @param p the position to check
     * @return the level of the position in the tree
     */
    public int level(Position<E> p) {
    
    	  Integer c = 0;
        if (binTree.root().equals(p)) {
            return c;
        }
        //aumento el nivel 2 posiciones , la de la raiz y al del nivel
        c = c + 1;
        /* si tiene izquierdo y derecho ya tiene como minimo un nivel m�s  
         hacemos un m�todo recursivo 
         utilizando una variable global que aumentaremos a medida que se llame recursivamente 
         a un m�todo auxilar */
        return levelAux(binTree, p,c);
    }
    
    
    
    private int levelAux(BinaryTree<E> binTree, Position<E> pos,Integer c) {
        if (binTree.parent(pos) != binTree.root()) {
            //si hace la llamada recursiva tiene un nivel
            c++;
            levelAux(binTree, binTree.parent(pos),c);
        }
        return c;
    }

}
