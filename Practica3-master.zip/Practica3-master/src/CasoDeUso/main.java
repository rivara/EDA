package CasoDeUso;

public class main {

	
	public static void main(String[] args) {

			Huffman h = new Huffman ("SUSIE SAYS IT IS EASY");
		    System.out.println(h.codificar('U'));
		    System.out.println(h.codificar('Y'));
		    System.out.println(h.codificar('I'));

	}

}
