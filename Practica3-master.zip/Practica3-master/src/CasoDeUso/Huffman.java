package CasoDeUso;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import material.tree.Position;
import material.tree.binarytree.LinkedBinaryTree;

public class Huffman {
	//ArrayList<Caracter> almacen = new ArrayList<Caracter> ();
	//List<LinkedBinaryTree <Caracter>> bosque = new ArrayList<LinkedBinaryTree <Caracter>> ();
	Set<Caracter> almacen = new HashSet<Caracter> ();
	List<LinkedBinaryTree <Caracter>> bosque = new ArrayList<LinkedBinaryTree <Caracter>> ();

/* Un constructor que recibe una cadena (tipo String), que determina
la frecuencia de aparici�n de cada car�cter y almacena esta informaci�n en la
estructura de datos que considere m�s adecuada. Finalmente, llama al m�todo
an�lisis (descrito en el siguiente apartado).*/
	public Huffman (String frase) {
		for (int i=0; i<frase.length(); i++) {
			char c = frase.charAt(i);
			Caracter caracter = findCaracter (c);
			if (caracter==null) {
				caracter = new Caracter (c);
				almacen.add(caracter);
			} else {
				caracter.setFrec(caracter.getFrec()+1);
			}
			
		}

		for (Caracter c: almacen) {
			LinkedBinaryTree <Caracter> arbol = new LinkedBinaryTree <Caracter>();
			arbol.addRoot(c);
			bosque.add(arbol);
		}

		
		while (bosque.size()>1) {
			LinkedBinaryTree <Caracter> a1 = dameMenor ();
			LinkedBinaryTree <Caracter> a2 = dameMenor ();
			LinkedBinaryTree <Caracter> nuevo = new LinkedBinaryTree <Caracter>();
			Caracter n = new Caracter ('#');
			n.setFrec(a1.root().getElement().getFrec()+a2.root().getElement().getFrec());
			Position<Caracter> raiz = nuevo.addRoot(n);
			Position<Caracter> raiz_izq = nuevo.insertLeft(raiz, a1.root().getElement());
			Position<Caracter> raiz_der = nuevo.insertRight(raiz, a2.root().getElement());
			
			CopiarArbol (nuevo, raiz_izq, a1, a1.root());
			CopiarArbol (nuevo, raiz_der, a2, a2.root());
			
			bosque.add(nuevo);
		}
		//LLAMO A ANALISIS PARA QUE ME CREE EL ARBOL CON LA CODIFICACI�N BINARIA
		analisis (bosque.get(0), bosque.get(0).root(), "");

	}
	
	
	
	public void CopiarArbol (LinkedBinaryTree <Caracter> destino, Position<Caracter> raiz_destino, LinkedBinaryTree <Caracter> origen, Position<Caracter> raiz_origen) {
		if (origen.hasRight(raiz_origen)) {
			Position<Caracter> derecha = destino.insertRight (raiz_destino, origen.right(raiz_origen).getElement());
			
			CopiarArbol (destino, derecha,origen, origen.right(raiz_origen));
		}
		if (origen.hasLeft(raiz_origen)) {
			Position<Caracter> izquierda = destino.insertLeft (raiz_destino, origen.left(raiz_origen).getElement());
			
			CopiarArbol (destino, izquierda,origen, origen.left(raiz_origen));
			
		}
	}
	
/*
b)Implementar un m�todo privado analisis que construya el �rbol
mediante el proceso iterativo descrito anteriormente.*/
	
	private void analisis (LinkedBinaryTree <Caracter> arbol, Position <Caracter> p, String codigo) {
		if (arbol.isLeaf(p)) {
			p.getElement().setCodificaciones(codigo);
		}else {
			analisis (arbol,arbol.left(p), codigo+"0");
			analisis (arbol,arbol.right(p), codigo+"1");
		}
	}
	public LinkedBinaryTree <Caracter> dameMenor () {
		LinkedBinaryTree <Caracter> menor = null;
		for (LinkedBinaryTree <Caracter> a: bosque) {
			if (menor==null) {
				menor = a;
			}else if (menor.root().getElement().getFrec()>a.root().getElement().getFrec()) {
				menor = a;
			}
		}
		
		bosque.remove(menor);
		return menor;
		
	}
	public Caracter findCaracter (char letra) {
		for (Caracter c: almacen) {
			if (c.getLetra()==letra) {
				return c;
			}
		}
		return null;
	}
	

	/*c)  Implementar un m�todo p�blico codificar que reciba un car�cter y
	devuelva un String con el c�digo binario de Huffman que lo identifica
	 * */

	public String codificar(char a)throws IllegalStateException {
		
		for (Caracter c: almacen) {
			if(c.getLetra()==a)
					return	c.getLetra()+"  "+c.getCodificaciones();
		}
	   throw new IllegalStateException("Error Ese termino no exite");
	}
	
}
