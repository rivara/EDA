package CasoDeUso;

public class Caracter {
	private char letra;
	private int frec;
	private String codificaciones="";
	
	//CONSTRUCTOR
	public Caracter(char letra){
		this.letra=letra;
		this.frec=1;
	}
	
	
	
	public char getLetra() {
		return letra;
	}
	public void setLetra(char letra) {
		this.letra = letra;
	}
	public int getFrec() {
		return frec;
	}
	public void setFrec(int frec) {
		this.frec = frec;
	}
	public String getCodificaciones() {
		return codificaciones;
	}
	public void setCodificaciones(String codificaciones) {
		this.codificaciones = codificaciones;
	}
}
