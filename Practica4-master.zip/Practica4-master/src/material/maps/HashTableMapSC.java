package material.maps;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Queue;
import java.util.Random;

/**
 * Separate chaining table implementation of hash tables. Note that all
 * "matching" is based on the equals method.
 *
 * @author A. Duarte, J. V�lez, J. S�nchez-Oro
 * @param <T>
 *            key type
 * @param <U>
 *            value type
 */
public class HashTableMapSC<K, V> implements Map<K, V> {

	private class HashEntry<T, U> implements Entry<T, U> {
		// Atributos
		protected T key;
		protected U value;

		public HashEntry(T k, U v) {
			key = k;
			value = v;

		}

		@Override
		public U getValue() {
			return value;
		}

		@Override
		public T getKey() {
			return key;
		}

		public U setValue(U val) {
			U oldValue = value;
			value = val;
			return oldValue;
		}

		@Override
		public boolean equals(Object o) {
			HashEntry<T, U> ent;
			try {
				ent = (HashEntry<T, U>) o;
			} catch (ClassCastException ex) {
				return false;
			}
			return (ent.getKey().equals(this.key))
					&& (ent.getValue().equals(this.value));
		}

		/**
		 * Entry visualization.
		 */
		@Override
		public String toString() {
			return "(" + key + "," + value + ")";
		}
	}

	// ok

	private class HashTableMapIterator<T, U> implements Iterator<Entry<T, U>> {
		private int pos;
		// Ojo
		private ArrayList<HashEntry<T, U>>[] bucket;
		private Queue<HashEntry<T, U>> elem = new ArrayDeque<HashEntry<T, U>>();

		// Ejercicio 2.2
		public HashTableMapIterator(ArrayList<HashEntry<T, U>>[] b, int num) {

			if (num == 0) {
				this.pos = b.length;
			} else {
				this.bucket = b;
				if (pos < bucket.length)
					for (HashEntry<T, U> e : bucket[pos])
						elem.add(e);

			}
		}

		private void goToNextElement(int start) {
			this.pos = start;
			while (pos < bucket.length
					&& (bucket[pos] == null || bucket[pos].isEmpty()))
				this.pos++;
		}

		@Override
		public boolean hasNext() {
			return !elem.isEmpty();
		}

		@Override
		public Entry<T, U> next() {
			Entry<T, U> ent = elem.remove();
			if (elem.isEmpty()) {
				goToNextElement(pos + 1);
				if (pos < bucket.length) {
					for (HashEntry<T, U> e : bucket[pos]) {
						elem.add(e);
					}
				}
			}
			return ent;
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException("Not supported yet.");
		}

	}

	/* ok */

	private class HashTableMapKeyIterator<T, U> implements Iterator<T> {
		public HashTableMapIterator<T, U> it;

		public HashTableMapKeyIterator(HashTableMapIterator<T, U> it) {
			this.it = it;
		}

		@Override
		public T next() {
			return it.next().getKey();
		}

		@Override
		public boolean hasNext() {
			return it.hasNext();
		}

		@Override
		public void remove() {
			// NO HAY QUE IMPLEMENTARLO
			throw new UnsupportedOperationException("Not implemented.");
		}
	}

	/* ok */

	private class HashTableMapValueIterator<T, U> implements Iterator<U> {
		public HashTableMapIterator<T, U> it;

		public HashTableMapValueIterator(HashTableMapIterator<T, U> it) {
			this.it = it;
		}

		@Override
		public U next() {
			return it.next().getValue();
		}

		@Override
		public boolean hasNext() {
			return it.hasNext();
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException("Not implemented.");
		}
	}

	/* ok */

	// REPASO -->

	private class HashEntryIndex {
		int index;
		boolean found;

		public HashEntryIndex(int index, boolean f) {
			this.index = index;
			this.found = f;
		}
	}

	protected int n = 0;
	protected int prime, capacity;
	protected long scale, shift;
	protected ArrayList<HashEntry<K, V>>[] bucket;

	/**
	 * Creates a hash table
	 */
	public HashTableMapSC() {
		this(109345121, 1000);
	}

	/**
	 * Creates a hash table.
	 *
	 * @param cap
	 *            initial capacity
	 */
	public HashTableMapSC(int cap) {
		this(109345121, cap); // reusing the constructor HashTableMap(int p, int
								// cap)
	}

	/**
	 * Creates a hash table with the given prime factor and capacity.
	 *
	 * @param p
	 *            prime number
	 * @param cap
	 *            initial capacity
	 */
	public HashTableMapSC(int p, int cap) {
		this.n = 0;
		this.prime = p;
		this.capacity = cap;
		this.bucket = (ArrayList<HashEntry<K, V>>[]) new ArrayList[capacity];
		Random rand = new Random();
		this.scale = rand.nextInt(prime - 1) + 1;
		this.shift = rand.nextInt(prime);
	}

	/**
	 * Hash function applying MAD method to default hash code.
	 *
	 * @param key
	 *            Key
	 * @return
	 */
	protected int hashValue(K key) {
		return (int) ((Math.abs(key.hashCode() * scale + shift) % prime) % capacity);
	}

	/**
	 * Returns the number of entries in the hash table.
	 *
	 * @return the size
	 */
	@Override
	public int size() {
		return n;
	}

	/**
	 * Returns whether or not the table is empty.
	 *
	 * @return true if the size is 0
	 */
	@Override
	public boolean isEmpty() {
		return (n == 0);
	}

	protected HashEntry<K, V> findEntry(K key) throws IllegalStateException {
		checkKey(key);
		int valorHash = hashValue(key);
		if (bucket[valorHash] == null || bucket[valorHash].isEmpty())
			return null;
		HashEntry<K, V> entry = null;
		for (HashEntry<K, V> e : bucket[valorHash]) {
			if (e.getKey().equals(key)) {
				entry = e;
				break;
			}
		}
		return entry;
	}

	/**
	 * Returns the value associated with a key.
	 *
	 * @param key
	 * @return value
	 */
	@Override
	public V get(K key) throws IllegalStateException {
		HashEntry<K, V> aux = findEntry(key);
		if (aux != null) {
			return aux.getValue();
		}
		return null;
	}

	/**
	 * Put a key-value pair in the map, replacing previous one if it exists.
	 *
	 * @param key
	 * @param value
	 * @return value
	 */
	@Override
	public V put(K key, V value) throws IllegalStateException {
		int valorHash = hashValue(key);
		if (bucket[valorHash] == null) {
			bucket[valorHash] = new ArrayList<>();
			bucket[valorHash].add(new HashEntry<K, V>(key, value));
			n++;
			return null;
		} else if (n >= capacity * 0.75) {
			rehash();
		}
		HashEntry<K, V> aux = findEntry(key);
		if (aux == null) {
			valorHash = hashValue(key);
			bucket[valorHash].add(new HashEntry<>(key, value));
			n++;
			return null;
		} else {
			V oldValue = aux.setValue(value);
			return oldValue;
		}
	}

	/**
	 * Removes the key-value pair with a specified key.
	 *
	 * @param key
	 * @return
	 */
	@Override
	public V remove(K key) throws IllegalStateException {
		HashEntry<K, V> aux = findEntry(key);
		if (aux == null)
			return null;
		int valorHash = hashValue(key);
		V valueRemove = aux.getValue();
		bucket[valorHash].remove(aux);
		n--;
		return valueRemove;
	}

	@Override
	public Iterator<Entry<K, V>> iterator() {
		return new HashTableMapIterator<K, V>(bucket, n);
	}

	/**
	 * Returns an iterable object containing all of the keys.
	 *
	 * @return
	 */
	@Override
	public Iterable<K> keys() {
		return new Iterable<K>() {
			public Iterator<K> iterator() {
				return new HashTableMapKeyIterator<K, V>(
						new HashTableMapIterator<K, V>(bucket, n));
			}
		};
	}

	/**
	 * Returns an iterable object containing all of the values.
	 *
	 * @return
	 */
	@Override
	public Iterable<V> values() {
		return new Iterable<V>() {
			public Iterator<V> iterator() {
				return new HashTableMapValueIterator<K, V>(
						new HashTableMapIterator<K, V>(bucket, n));
			}
		};
	}

	/**
	 * Returns an iterable object containing all of the entries.
	 *
	 * @return
	 */
	@Override
	public Iterable<Entry<K, V>> entries() {
		return new Iterable<Entry<K, V>>() {
			public Iterator<Entry<K, V>> iterator() {
				return new HashTableMapIterator<K, V>(bucket, n);
			}
		};
	}

	/**
	 * Determines whether a key is valid.
	 *
	 * @param k
	 *            Key
	 */
	protected void checkKey(K k) {
		// We cannot check the second test (i.e., k instanceof K) since we do
		// not know the class K
		if (k == null) {
			throw new IllegalStateException("Invalid key: null.");
		}
	}

	/**
	 * Increase/reduce the size of the hash table and rehashes all the entries.
	 */
	protected void rehash() {
		capacity = 2 * capacity;
		ArrayList<HashEntry<K, V>>[] old = bucket;
		bucket = (ArrayList<HashEntry<K, V>>[]) new ArrayList[capacity];
		java.util.Random rand = new java.util.Random();
		scale = rand.nextInt(prime - 1) + 1;// 63617198;////53520545;//
		shift = rand.nextInt(prime);// 60182061;////91827999;//
		n = 0;
		for (ArrayList<HashEntry<K, V>> e : old) {
			if (e != null && !e.isEmpty()) {
				for (HashEntry<K, V> ent : e) {
					put(ent.getKey(), ent.getValue());
				}
			}
		}
	}
}
