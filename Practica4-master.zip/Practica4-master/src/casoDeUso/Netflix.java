package casoDeUso;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import material.maps.HashTableMapLP;

public class Netflix {

	// Atributos
	HashTableMapLP<String, Movie> htTitulo = new HashTableMapLP<String, Movie>();
	// HashTableMapLP<Integer, ArrayList<Movie>> htAnio = new
	// HashTableMapLP<Integer, ArrayList<Movie>>();
	// HashTableMapLP<String, ArrayList<Movie>> htGenero = new
	// HashTableMapLP<String, ArrayList<Movie>>();
	HashTableMapLP<Integer, Set<Movie>> htAnio = new HashTableMapLP<Integer, Set<Movie>>();
	HashTableMapLP<String, Set<Movie>> htGenero = new HashTableMapLP<String, Set<Movie>>();

	public void loadFile(String archivo) throws FileNotFoundException,
			IOException {
		String cadena;
		int contador = 0;
		FileReader f = new FileReader(archivo);
		BufferedReader b = new BufferedReader(f);

		while (!(cadena = b.readLine()).isEmpty()) {
			String partes[] = cadena.split(" - ");

			// nombre
			String nombre = partes[0];

			// a�o
			String anio = partes[1];

			// puntuaciones
			ArrayList<Float> puntos = new ArrayList<Float>();
			puntos.add(Float.parseFloat(partes[2]));

			// generos
			String g = partes[3].substring(1, partes[3].length() - 2);
			String generosL[] = g.split(", ");
			ArrayList<String> generos = new ArrayList<String>();
			for (int i = 0; i < generosL.length; i++) {

				generos.add(generosL[i]);
			}

			Movie p = new Movie(nombre, Integer.parseInt(anio), generos, puntos);

			// agrego por pelicula a la HasTable HSpelicula
			htTitulo.put(p.getTitulo(), p);

			// Agrego por genero

			for (String ge : generos) {
				if (htGenero.get(ge) == null) {
					Set<Movie> aux = new HashSet<Movie>();
					aux.add(p);
					htGenero.put(ge, aux);
				} else {
					Set<Movie> aux = htGenero.get(ge); // htGenero.get(ge);
					aux.add(p);
				}
			}

			// agregar por a�o

			if (htAnio.get(p.getAnio()) == null) {
				Set<Movie> aux2 = new HashSet<Movie>();
				aux2.add(p);
				htAnio.put(p.getAnio(), aux2);
			} else {
				Set<Movie> aux2 = htAnio.get(p.getAnio());
				aux2.add(p);
			}
		}
		// cierro la lectura
		b.close();

	}

	public Movie findTitle(String title) {
		return htTitulo.get(title);
	}

	public Set<Movie> findYear(int year) {
		return  htAnio.get(year);
	}

	public Iterable<Movie> findScore(float score) {
		ArrayList<Movie> salida = new ArrayList<Movie>();
		Iterable<material.maps.Entry<String, Movie>> entr = htTitulo.entries();
		for (material.maps.Entry<String, Movie> en : entr) {
			if (en.getValue().media() >= score) {
				salida.add(en.getValue());
			}
	
		}

		return salida;
	}

	public void addScore(String title, float score) {
		Movie pelicula = htTitulo.get(title);
		pelicula.agregaPuntos(score);
	}

	public Set<Movie> findType(String type) {
		Set<Movie> pelicula = htGenero.get(type);
	
		System.out.println(pelicula.size()+"***");
		return pelicula;
	}

	public Set<Movie> findType(Set<String> type) {
		Set<Movie> listaPeliculas = new HashSet<Movie>();
		// ArrayList<Movie> pelicula= htGenero.get(type);
		for (String t : type) {
			listaPeliculas.addAll(htGenero.get(t));
		}
		return listaPeliculas;
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		Netflix net = new Netflix();
		// Load=> Carga el fichero y lo vuelca a 3 Mapas
		net.loadFile("C:\\ECLIPSE\\WS_EDA_URJC\\Practica4\\bin\\casoDeUso\\netflix.txt");

		// FindTitle retorna la pel�cula
		System.out.println("\n\n>findTitle retorna la pel�cula ");
		System.out.println(net.findTitle("Pacific Rim").toString());

		// findYear retorna el conjunto de pel�cula/as de ese a�o
		System.out
				.println("\n\n>findYear retorna el conjunto de pel�cula/as de ese a�o ");
		if (net.findYear(2001) == null) {
			System.out.println("no hay peliculas ese a�o");
		} else {
			for (Movie m : net.findYear(2001)) {
				System.out.println(m.titulo + "**");
			}
		}

		// Findscore retorna las pelicula/s todas las pel�culas almacenadas que
		// tengan dicha puntuaci�n o superior.
		System.out
				.println("\n\n>findscore retorna las pelicula/s todas las pel�culas almacenadas que tengan dicha puntuaci�n o superior.");
		for (Movie m : net.findScore(1)) {
			System.out.println(m.titulo + "\t" + m.puntos + "pts");
		}

		// addScore modificacla puntuaci�n de una pelicula
		System.out
				.println("\n\n>addScore modificacla puntuaci�n de una pelicula");
		System.out.println(net.findTitle("Pacific Rim").toString());
		net.addScore("Pacific Rim", 33);
		System.out.println(net.findTitle("Pacific Rim").toString());

		// findType encuentra el tipo de pelicula que contenga el genero
		// indicado
		System.out.println("\n\n>findType1 encuentra los tipos de pelicula que contenga los generos indicado");

		if (net.findType("premiada") == null) {
			System.out.println("no hay peliculas de ese g�nero");
		} else {
			for (Movie m : net.findType("premiada")) {
				System.out.println(m.titulo);
			}
		}
		
		// findType encuentra los tipos de pelicula que contenga los generos
		// indicado
		System.out
				.println("\n\n>findType2 encuentra los tipos de pelicula que contenga los generos indicado");
		Set<String> pelis = new HashSet<String>();
		pelis.add("premiada");
		pelis.add("acci�n");
		// findType encuentra el tipo de pelicula que se le ha metido
		if (net.findType(pelis) == null) {
			System.out.println("no hay peliculas de ese g�nero");
		} else {
			for (Movie m : net.findType(pelis)) {
				System.out.println(m.titulo);
			}
		}
	}

}
