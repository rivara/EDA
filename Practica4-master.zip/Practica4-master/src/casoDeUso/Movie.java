package casoDeUso;

import java.util.ArrayList;

public class Movie {

	// Atibutos
	String titulo;
	int anio;
	 ArrayList<Float> puntos;
	ArrayList<String> generos;

	// Constructor
	public Movie(String t, int a, ArrayList<String> g, ArrayList<Float> p) {
		titulo = t;
		anio = a;
		puntos = p;
		generos = g;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	public ArrayList<Float> getPuntos() {
		return puntos;
	}

	public void setPuntos(ArrayList<Float> puntos) {
		this.puntos = puntos;
	}

	public ArrayList<String> getGeneros() {
		return generos;
	}

	public void setGeneros(ArrayList<String> generos) {
		this.generos = generos;
	}
	
	//
	public Float media () {
		float acu = 0;
		for (Float aux: puntos) {
			acu = acu + aux;
		}
		return (acu/puntos.size());
		
	}
	
	public void agregaPuntos (Float p) {
		this.puntos.add (p);
	}
	
	public String toString() {
		String cadena =" Pelicula:"+this.titulo+ "\n A�o:"+ this.anio+ "\n Puntuacion:"+this.media();
		return cadena;
	}
	

}
