package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import material.tree.LinkedTree;
import material.tree.Position;
import material.tree.iterator.FrontIteratorFactory;
import material.tree.iterator.PostorderIteratorFactory;
import material.tree.iterator.PreorderIteratorFactory;

import org.junit.Test;

public class FrontOrderTest {

	@Test
	public void test() {
		// TODO Auto-generated method stub
		LinkedTree arbol = new LinkedTree();
		boolean esta = true;
		// raiz
		Position raiz = arbol.addRoot("1");
		// nivel 0
		Position a11 = arbol.add("2", raiz);
		Position a12 = arbol.add("3", raiz);
		Position a13 = arbol.add("4", raiz);
		// nivel 1
		Position last = arbol.add("5", a12);
		FrontIteratorFactory frontiteratorfactory = new FrontIteratorFactory();
		arbol.setIterator(frontiteratorfactory);
		Iterator<Position<String>> itt = arbol.iterator();
		ArrayList<String> lista = new ArrayList<String>();
		lista.add("2");
		lista.add("5");
		lista.add("4");
		Iterator<String> it = lista.iterator();
		while (it.hasNext()) {
			if (!it.next().equals(itt.next().getElement()))
				esta = false;

		}
		assertTrue(esta);
	}
			

}
