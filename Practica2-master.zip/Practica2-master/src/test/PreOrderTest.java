package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import material.tree.LinkedTree;
import material.tree.Position;
import material.tree.iterator.PreorderIteratorFactory2;

import org.junit.Test;

public class PreOrderTest {

	@Test
	public void test() {

		LinkedTree arbol = new LinkedTree();
		boolean esta = true;
		// raiz
		Position raiz = arbol.addRoot("1");
		// nivel 0
		Position a11 = arbol.add("2", raiz);
		Position a12 = arbol.add("3", raiz);
		Position a13 = arbol.add("4", raiz);
		// nivel 1
		Position last = arbol.add("5", a12);
		//Position last2 = arbol.add("p", a11);
		PreorderIteratorFactory2 preordeniteratorfactory2 = new PreorderIteratorFactory2();
		arbol.setIterator(preordeniteratorfactory2);
		
		Iterator<Position<String>> itt = arbol.iterator();
	
		String recorrido_deberia_ser = "12354";
		String recorrido_real = "";
		
		while (itt.hasNext()){
			String n = itt.next().getElement();
			recorrido_real = recorrido_real +n;
		}
		System.out.println (recorrido_real);
		assertTrue(recorrido_deberia_ser.equals(recorrido_real));
	}
}
