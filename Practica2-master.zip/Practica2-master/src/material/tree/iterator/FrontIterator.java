/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package material.tree.iterator;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Queue;

import material.tree.Position;
import material.tree.Tree;

/**
 * Generic iterator for trees
 * 
 * @author Ricardo Valle
 * @param <E> the type of elements stored in the tree
 */
public class FrontIterator<E> implements Iterator<Position<E>> {

    private final Queue<Position<E>> nodeQueue;
    private final Tree<E> tree;

    public void frontorderaux(Position<E> start , Queue<Position<E>>nodeQueue){
    	for(Position<E> hijo: tree.children(start)){
    		frontorderaux(hijo ,nodeQueue);
    	}
    	if(tree.isLeaf(start))
    		nodeQueue.add(start); 
    }
    

    public FrontIterator(Tree<E> tree, Position<E> start) {
        nodeQueue = new ArrayDeque<>();
        this.tree = tree;
        frontorderaux(tree.root() ,nodeQueue);
    }   
    
    public FrontIterator(Tree<E> tree) {
        nodeQueue = new ArrayDeque<>();
        this.tree = tree;
        frontorderaux(tree.root() ,nodeQueue);
    }   
    
    @Override
    public boolean hasNext() {
        return (nodeQueue.size() != 0);
    }

    @Override
    public Position<E> next() {
        Position<E> aux= nodeQueue.remove();
        return aux;
    }
    
}
