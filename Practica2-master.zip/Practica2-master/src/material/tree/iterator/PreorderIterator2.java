/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package material.tree.iterator;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Queue;
import java.util.Stack;

import material.tree.Position;
import material.tree.Tree;

/**
 * Generic iterator for trees
 * 
 * @author A. Duarte, J. Vélez, J. Sánchez-Oro
 * @param <E>
 *            the type of elements stored in the tree
 */
public class PreorderIterator2<E> implements Iterator<Position<E>> {

	private final Stack<Position<E>> nodeStack;
	private final Tree<E> tree;

	public PreorderIterator2(Tree<E> tree, Position<E> start) {
		nodeStack = new Stack<>();
		this.tree = tree;
		nodeStack.add(start);

	}

	public PreorderIterator2(Tree<E> tree) {
		nodeStack = new Stack<>();
		this.tree = tree;
		nodeStack.add(tree.root());

	}

	@Override
	public boolean hasNext() {
		return (nodeStack.size() != 0);
	}

	@Override
	public Position<E> next() {
		Stack<Position<E>> pila_aux = new Stack<Position<E>>();

		Position<E> aux = nodeStack.pop();

		for (Position<E> node : tree.children(aux)) {
			pila_aux.push(node);
		}
		while (!pila_aux.isEmpty()) {
			nodeStack.push(pila_aux.pop());
		}

		return aux;

	}

}
