package material.tree;

import java.util.*;

import material.tree.iterator.TreeIteratorFactory;
import material.tree.iterator.BSFIteratorFactory;

/**
 * A linked class for a tree where nodes have an arbitrary number of children.
 *
 * @author Raul Cabido, Abraham Duarte, Jose Velez, Jesús Sánchez-Oro
 * @param <E>
 *            the elements stored in the tree
 */
public class LCRSTree<E> implements Tree<E> {

	public class TreeNode<T> implements Position<T> {

		private T element;
		private TreeNode<T> parent;
		private TreeNode<T> children; // children nodes
		private TreeNode<T> brother;
		private LCRSTree<T> myTree; // A reference to the tree where the node

		/** Main constructor */
		public TreeNode(LCRSTree<T> t, T e, TreeNode<T> p, TreeNode<T> c,
				TreeNode<T> b) {
			this.element = e;
			this.parent = p;
			this.children = c;
			this.brother = b;
			this.myTree = t;

		}

		/** Returns the element stored at this position */
		@Override
		public T getElement() {
			return element;
		}

		/** Sets the element stored at this position */
		public final void setElement(T o) {
			element = o;
		}

		/** Returns the children of this position */
		public TreeNode<T> getChildren() {
			return children;
		}

		/** Sets the right child of this position */
		public final void setChildren(TreeNode<T> c) {
			children = c;
		}

		/** Returns the parent of this position */
		public TreeNode<T> getParent() {
			return parent;
		}

		/** Sets the parent of this position */
		public final void setParent(TreeNode<T> v) {
			parent = v;
		}

		/** Returns the parent of this position */
		public TreeNode<T> getBrother() {
			return brother;
		}

		/** Sets the parent of this position */
		public final void setBrother(TreeNode<T> v) {
			brother = v;
		}

		/**
		 * Consults the tree in which this node is stored
		 * 
		 * @return a reference to the tree where the node belongs
		 */
		public LCRSTree<T> getMyTree() {
			return myTree;
		}

		/**
		 * Sets the tree where this node belongs
		 * 
		 * @param myTree
		 *            the tree where this node belongs
		 */
		public void setMyTree(LCRSTree<T> myTree) {
			this.myTree = myTree;
		}

		public void remove(LCRSTree<E>.TreeNode<E> node) {
			// TODO Auto-generated method stub

		}

	}

	private TreeNode<E> root;
	private int size;
	private TreeIteratorFactory<E> iteratorFactory; // The factory of iterators

	/**
	 * Creates an empty tree.
	 */
	public LCRSTree() {
		root = null;
		size = 0;
		this.iteratorFactory = new BSFIteratorFactory<>();
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return (size == 0);
	}

	@Override
	public boolean isInternal(Position<E> v) throws IllegalStateException {
		return !isLeaf(v);
	}

	@Override
	public boolean isLeaf(Position<E> p) throws IllegalStateException {
		TreeNode<E> node = checkPosition(p);
		return (node.getChildren() == null);
	}

	@Override
	public boolean isRoot(Position<E> p) throws IllegalStateException {
		TreeNode<E> node = checkPosition(p);
		return (node == this.root());
	}

	@Override
	public Position<E> root() throws IllegalStateException {
		if (root == null) {
			throw new IllegalStateException("The tree is empty");
		}
		return root;
	}

	@Override
	public Position<E> parent(Position<E> p) throws IllegalStateException {
		TreeNode<E> node = checkPosition(p);
		Position<E> parentPos = (Position<E>) node.getParent();
		if (parentPos == null) {
			throw new IllegalStateException("The node has not parent");
		}
		return parentPos;
	}

	@Override
	public Iterable<? extends Position<E>> children(Position<E> p)
			throws IllegalStateException {
		TreeNode<E> node = checkPosition(p);

		TreeNode<E> children = node.getChildren();
		// lista para acumular todos los hijos
		ArrayList<TreeNode<E>> childrens = new ArrayList<TreeNode<E>>();
		while (children != null) {
			childrens.add(children);
			children = children.getBrother();
		}
		return childrens;
	}

	public E replace(Position<E> p, E e) throws IllegalStateException {
		TreeNode<E> node = checkPosition(p);
		E temp = p.getElement();
		node.setElement(e);
		return temp;
	}

	@Override
	public Position<E> addRoot(E e) throws IllegalStateException {
		if (!isEmpty()) {
			throw new IllegalStateException("Tree already has a root");
		}
		size = 1;
		root = new TreeNode<>(this, e, null, null, null);
		return root;
	}

	public void swapElements(Position<E> p1, Position<E> p2)
			throws IllegalStateException {
		if (p1 == p2)
			throw new IllegalStateException("This is the same pinter");
		TreeNode<E> node1 = checkPosition(p1);
		TreeNode<E> node2 = checkPosition(p2);
		E temp = p2.getElement();
		node2.setElement(p1.getElement());
		node1.setElement(temp);
	}

	private TreeNode<E> checkPosition(Position<E> p)
			throws IllegalStateException {
		if (p == null || !(p instanceof TreeNode)) {
			throw new IllegalStateException("The position is invalid");
		}
		TreeNode<E> aux = (TreeNode<E>) p;

		if (aux.getMyTree() != this) {
			throw new IllegalStateException("The node is not from this tree");
		}
		return aux;
	}

	public Position<E> add(E element, Position<E> p) {
		TreeNode<E> parent = checkPosition(p);
		TreeNode<E> newNode = new TreeNode<>(this, element, parent, null, null);
		TreeNode<E> childrenParent = parent.getChildren();
		if (childrenParent == null) {
			parent.setChildren(newNode);
		} else {
			while (childrenParent.getBrother() != null)
				childrenParent = childrenParent.getBrother();
			childrenParent.setBrother(newNode);

		}

		size++;
		return newNode;
	}

	/**
	 * Removes a node and its corresponding subtree rooted at node.
	 *
	 * @param p
	 *            the position of the node to be removed.
	 * @throws IllegalStateException
	 *             if the position is not valid
	 */

	public void remove(Position<E> p) throws IllegalStateException {
		TreeNode<E> node = checkPosition(p);
		if (node.getParent() != null) {
			Iterator<Position<E>> it = this.iteratorFactory.createIterator(
					this, p);
			int cont = 0;
			while (it.hasNext()) {
				it.next();
				cont++;
			}
			size = size - cont;

			TreeNode<E> parent = node.getParent();
			// parent.getChildren().remove(node);
			TreeNode<E> aux = parent.getChildren();
			if (aux == node) {
				parent.setChildren(node.getBrother());
			} else {
				while (aux.getBrother() != node)
					aux = aux.getBrother();
				aux.setBrother(node.getBrother());
			}

		} else {
			this.root = null;
			this.size = 0;
		}
		node.setMyTree(null);
	}

	public void setIterator(TreeIteratorFactory<E> iteratorFactory) {
		this.iteratorFactory = iteratorFactory;
	}

	@Override
	public Iterator<Position<E>> iterator() {
		return this.iteratorFactory.createIterator(this);
	}



	/**
	 * Moves a node and its corresponding subtree (rooted at pOrig) to make it
	 * as a new children of pDest
	 */
	public Position<E> moveSubtree(Position<E> pOrig, Position<E> pDest)
			throws IllegalStateException {
		TreeNode<E> n1 = this.checkPosition(pOrig);
		TreeNode<E> n2 = this.checkPosition(pDest);
		TreeNode<E> parent = n1.getParent();
		//nos posicionamos en el primer nodo de origen
		if (parent.getChildren() == n1) {
			//actualizo el padre origen con los hijos de origen y borro los hermanos de origen
			parent.setChildren(n1.getChildren());
			n1.setBrother(null);
		} else {
			//en caso contrario "coso" la lista
			TreeNode<E> childrens = parent.getChildren();
			while (childrens.getBrother() != n1)
				childrens = childrens.getBrother();
			childrens.setBrother(n1.getBrother());
		}
		//meto los nodos de origen a destino
		TreeNode<E> childrenn2 = n2.getChildren();
		//si no tiene origen hijos los meto a "cap�n"
		if (childrenn2 == null) {
			n2.setChildren(n1);
		} else {
			//
			while ((childrenn2.getBrother() != null))
				childrenn2 = childrenn2.getBrother();
			
			childrenn2.setBrother(n1);
		}
		n1.setBrother(null);
		return n2;
	}

}
