package casoDeUso;

public class FamilyMember {

	//Atributos
	private String id="";
	private String nombre="";
	private String apellido="";
	private String genero="";
	private Integer edad;	
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellidos() {
		return apellido;
	}


	public void setApellidos(String apellidos) {
		this.apellido = apellidos;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public Integer getEdad() {
		return edad;
	}


	public void setEdad(Integer edad) {
		this.edad = edad;
	}


	
	


}
