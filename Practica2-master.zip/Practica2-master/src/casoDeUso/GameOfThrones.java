package casoDeUso;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import com.sun.org.apache.bcel.internal.generic.FMUL;

import material.tree.LinkedTree;
import material.tree.Position;

public class GameOfThrones {

	private LinkedTree<FamilyMember> tree = new LinkedTree<FamilyMember>();

	// METODOS DE LA CLASE

	public void loadFile(String archivo) throws FileNotFoundException,
			IOException {
		// Recorro el fichero hasta ---- y lo meto en una arrayList
		ArrayList<FamilyMember> contenedor = new ArrayList<FamilyMember>();
		String cadena;
		int contador = 0;
		FileReader f = new FileReader(archivo);
		BufferedReader b = new BufferedReader(f);
		while ((cadena = b.readLine()) != null) {

			if (cadena.charAt(0) == '-') {
				break;
			}
			String partes[] = cadena.split(" ");
			FamilyMember fm = new FamilyMember();
			fm.setId(partes[0]);
			fm.setNombre(partes[2]);
			fm.setApellidos(partes[3]);
			fm.setGenero(partes[4]);
			fm.setEdad(Integer.parseInt(partes[5]));
			contenedor.add(fm);
			contador++;
		}

		Integer familias = Integer.parseInt(b.readLine().toString());
		// crea la raiz del arbol contenedor
		// un family memeber vacio
		FamilyMember root = new FamilyMember();
		Position<FamilyMember> raiz = tree.addRoot(root);

		// voy crear las N ramas con las N familias
		for (Integer i = 0; i < familias; i++) {
			// System.out.println(b.readLine().toString());
			String id = b.readLine().toString();
			FamilyMember padre = buscaID(id, contenedor);
			tree.add(padre, raiz);
		}
		// relaciono las diferentes familias

		while ((cadena = b.readLine()) != null) {
			// separo padre hijo
			String pieza[] = cadena.split(" -> ");
			// busca la posicion del padre en el arbol
			Position<FamilyMember> posPadre = buscaPos(pieza[0], tree.root());
			// busco el hijo
			FamilyMember hijo = buscaID(pieza[1], contenedor);
			// a�ado al arbol
			// compruebo que no sean huerfano
			if (posPadre != null) {
				tree.add(hijo, posPadre);
			}
		}
		// cierro la lectura
		b.close();

	}

	// metodo auxiliar busca IDS
	private FamilyMember buscaID(String id, ArrayList<FamilyMember> contenedor)
			throws IllegalStateException {
		for (Integer i = 0; i < contenedor.size(); i++) {
			if (id.equals(contenedor.get(i).getId())) {
				return contenedor.get(i);
			}
		}
		throw new IllegalStateException("Este personaje no existe");
	}

	public Position<FamilyMember> buscaPos(String id, Position<FamilyMember> pos) {
		if (pos.getElement().getId().equals(id)) {
			// caso base
			return pos;
		} else {
			// caso recursivo
			for (Position<FamilyMember> p : tree.children(pos)) {
				Position<FamilyMember> resultado = buscaPos(id, p);
				if (resultado != null)
					return resultado;
			}
		}
		return null;
	}

	public Position<FamilyMember> buscaPorApellido(String surname,
			Position<FamilyMember> pos) {
		if (pos.getElement().getApellidos().equals(surname)) {
			// caso base
			return pos;
		} else {
			// caso recursivo
			for (Position<FamilyMember> p : tree.children(pos)) {
				Position<FamilyMember> resultado = buscaPorApellido(surname, p);
				if (resultado != null)
					return resultado;
			}
		}

		return null;
	}

	public LinkedTree<FamilyMember> getFamily(String surname) {
		// creo un arbol vacio
		LinkedTree<FamilyMember> treeAux = new LinkedTree<FamilyMember>();
		// Bueco el cabeza de familia de ese miembro
		Position<FamilyMember> pos = buscaPorApellido(surname, tree.root());
		// creo la raiz del nuevo arbol
		Position<FamilyMember> posAux = treeAux.addRoot(pos.getElement());
		// llamada recursiva hasta las hojas con sus miembros INCOMPLETO
		getFamilyAux(treeAux, posAux, tree, pos);
		return treeAux;
	}

	// METODO AUXILIAR RECUSRIVO PARA METER ARBOL VIEJO EN NUEVO
	private void getFamilyAux(LinkedTree<FamilyMember> treeAux,
			Position<FamilyMember> posAux, LinkedTree<FamilyMember> tree,
			Position<FamilyMember> pos) {

		Position<FamilyMember> PosAuxiliar = posAux;
		posAux = null;
		for (Position<FamilyMember> p : tree.children(pos)) {
			// inserto en el nuevo arbol y me quedo con la posici�n de
			// referencia
			posAux = treeAux.add(p.getElement(), PosAuxiliar);
			// llamada recursiva
			getFamilyAux(treeAux, posAux, tree, p);
		}

	}

	public Position<FamilyMember> buscaPorNombre(String name,
			Position<FamilyMember> pos) {
		if (pos.getElement().getNombre().equals(name)) {
			// caso base
			return pos;
		} else {
			// caso recursivo
			for (Position<FamilyMember> p : tree.children(pos)) {
				Position<FamilyMember> resultado = buscaPorNombre(name, p);
				if (resultado != null)
					return resultado;
			}
		}

		return null;
	}

	public boolean areFamily(String name1, String name2) {
		Boolean verdad = false;
		String nombre2 = buscaPorNombre(name2, tree.root()).getElement()
				.getId();

		// llamada al arbol de hacer familia
		Iterator<Position<FamilyMember>> it = tree.iterator();// this.getFamily(
		// buscaPorNombre(name1, tree.root()).getElement().getApellidos())
		// .iterator();
		while (it.hasNext()) {

			if (it.next().getElement().getId().equals(nombre2))
				verdad = true;
		}
		return verdad;
	}

	
	public boolean areFamily2(String name1, String name2) {
		Position<FamilyMember> uno = buscaPorNombre(name1, tree.root());
		Position<FamilyMember> dos = buscaPorNombre(name2, tree.root());
		ArrayList<Position<FamilyMember>> ancestros1 = new ArrayList<Position<FamilyMember>>();
		while (!tree.isRoot(uno)) {
			ancestros1.add(uno);
			uno = tree.parent(uno);
		}

		while (!tree.isRoot(dos)) {
			if (ancestros1.contains(dos)) {
				return true;
			}
			dos = tree.parent(dos);
		}
		return false;
	}

	public String findHeir(String surname) {
		// genero el arbol de surname y recojo su raiz
		LinkedTree<FamilyMember> arbol = this.getFamily(surname);
		Position<FamilyMember> padre = arbol.root();
		String varon = "";
		String mujer = "";
		Integer mayorVaron = 0;
		Integer mayorMujer = 0;
		// recorro en un foreach
		// si encuentra un varon lo expulsa
		// si no se va quedando con la mujer mayor

		for (Position<FamilyMember> hijo : arbol.children(padre)) {
			// Si es varon entra por aqui y busca el mayor
			if (hijo.getElement().getGenero().equals("(M)")) {
				varon = hijo.getElement().getNombre() + "  "
						+ hijo.getElement().getApellidos();
				mayorVaron = hijo.getElement().getEdad();
				// si no hace lo mismo con las mujeres
			} else {
				if (hijo.getElement().getEdad() > mayorMujer) {
					mujer = hijo.getElement().getNombre() + "  "
							+ hijo.getElement().getApellidos();
					mayorMujer = hijo.getElement().getEdad();
				}
			}
		}
		// lo recorro con un iterator
		if (varon == "") {
			return mujer;
		} else {
			return varon;
		}

	}

	public void changeFamily(String memberName, String newParent) {
		Position<FamilyMember> pOrig = buscaPorNombre(memberName, tree.root());
		Position<FamilyMember> pDest = buscaPorNombre(newParent, tree.root());
		tree.moveSubtree(pOrig, pDest);
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		// INSTANCIAMOS LA CLASE
		GameOfThrones gt = new GameOfThrones();

		// CARGA E INSTANCIA DE LA CLASE
		gt.loadFile("C:\\ECLIPSE\\WS_EDA_URJC\\Practica2\\bin\\casoDeUso\\got_edited.txt");

		// CREAMOS EL ARBOL Y LO RECORREMOS
		Iterator<Position<FamilyMember>> it = gt.getFamily("Tully").iterator();
		while (it.hasNext()) {
			Position<FamilyMember> personaje = it.next();
			System.out.println(personaje.getElement().getNombre() + " "
					+ personaje.getElement().getApellidos() + " "
					+ personaje.getElement().getEdad());
		}

		// COMPARO SI 2 PERSONAJES SON DE LA MISMA FAMILIA
		System.out.println(gt.areFamily2("Rickard", "Sansa"));
		// EL PRIMER HIJO O LA HIJA MAYOR
		System.out.println(gt.findHeir("Tully"));

		// CAMBIO DE POSICIONES 
		 gt.changeFamily("Theon","Renly");

		
		  Iterator<Position<FamilyMember>> it2 =
		  gt.getFamily("Greyjoy").iterator(); while (it2.hasNext()) {
		  System.out.println(it2.next().getElement().getNombre()); }
		 

	}

}
